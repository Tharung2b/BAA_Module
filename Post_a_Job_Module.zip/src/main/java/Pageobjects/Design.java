package Pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Design {

	
		// TODO Auto-generated method stub
		WebDriver driver;
		By where_in_design=By.xpath("//*[@id=\"design_process_status\"]/div/div[1]/label");
		By provide_details=By.id("job_description");
		By Select_thretags1=By.cssSelector("#keywords > span:nth-child(1)");
		By attatch=By.xpath("//div//button[@title=\"Attach file\"]");
		By design_continue=By.xpath("//button[@class='ant-btn css-6rzz9k ant-btn-primary custom-btn custom-btn__long btn__solid-primary']");
		public Design(WebDriver driver) {
			this.driver=driver;
		}
		public WebElement getwhere_in_design() {
			return driver.findElement(where_in_design);			
		}
		public WebElement getprovide_details() {
			return driver.findElement(provide_details);			
		}
		public WebElement getSelect_thretags1() {
			return driver.findElement(Select_thretags1);			
		}
		public WebElement getattatch() {
			return driver.findElement(attatch);			
		}
		public WebElement getdesign_continue() {
			return driver.findElement(design_continue);			
		}

}
