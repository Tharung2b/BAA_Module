package Pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Contact_info {
	public WebDriver driver;
	By Org_or_person=By.cssSelector("#user_as > label:nth-child(2)");
	By Select_countrycode=By.xpath("//select[@class='PhoneInputCountrySelect']");
	By enter_ph_num=By.xpath("//input[@class='PhoneInputInput']");
	By first_Name=By.id("first_name");
	By last_Name=By.id("last_name");
	By email=By.id("email");
	By password=By.id("password");
	By terms_condn=By.id("terms_privacy");
	By captcha=By.xpath("//div[@class='recaptcha-checkbox-border']");
	By save_submit=By.xpath("//button[@class='ant-btn css-6rzz9k ant-btn-primary custom-btn custom-btn__long btn__solid-primary']");
	public Contact_info(WebDriver driver) {
		this.driver=driver;
		
	}
	public WebElement getOrg_or_person() {
		return driver.findElement(Org_or_person);
	}
	public WebElement getSelect_countrycode() {
		return driver.findElement(Select_countrycode);
	}
	public WebElement getenter_ph_num() {
		return driver.findElement(enter_ph_num);
	}
	public WebElement getfirst_Name() {
		return driver.findElement(first_Name);
	}
	public WebElement getlast_Name() {
		return driver.findElement(last_Name);
	}
	public WebElement getemail() {
		return driver.findElement(email);
	}
	public WebElement getpassword() {
		return driver.findElement(password);
	}
	public WebElement getterms_condn() {
		return driver.findElement(terms_condn);
	}
	
	public WebElement getsave_submit() {
		return driver.findElement(save_submit);
	}

}
