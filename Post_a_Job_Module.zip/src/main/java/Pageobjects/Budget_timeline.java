package Pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Budget_timeline {
	public WebDriver driver;
	By budget=By.cssSelector("#budget");
	By budget_symbol=By.id("currency");
	By bdate=By.xpath("//div[@class='ant-picker-input']//input[@placeholder='Before date']");
	By budget_timeline_continue=By.xpath("//button[@class='ant-btn css-6rzz9k ant-btn-primary custom-btn custom-btn__long btn__solid-primary']");
	public Budget_timeline(WebDriver driver) {
		this.driver=driver;
		
	}
	
	public WebElement getbudget() {
		return driver.findElement(budget);
	}
	public WebElement getbudget_symbol() {
		return driver.findElement(budget_symbol);
	}
	public WebElement getbdate() {
		return driver.findElement(bdate);
	}
	public WebElement getbudget_timeline_continue() {
		return driver.findElement(budget_timeline_continue);
	}

}
