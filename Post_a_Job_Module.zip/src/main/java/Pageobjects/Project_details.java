package Pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Project_details {
	public WebDriver driver;
	By coockie=By.cssSelector(".button-close");
	By projectname=By.id("project_name");
	By muralgo=By.className("ant-checkbox-input");
	By location=By.xpath("//input[@class='ant-input css-6rzz9k']");
	By type_of_property=By.cssSelector("#property_type > label:nth-child(1)");
	By projectdetails_continuebtn=By.xpath("//div[@class=\"project__form-footer custom-flex-row\"]");
	public Project_details(WebDriver driver) {
		this.driver=driver;
	}
	public WebElement getcoockie() {
		return driver.findElement(coockie);
	}
	public WebElement getprojectname() {
		return driver.findElement(projectname);
	}
	public WebElement getmuralgo() {
		return driver.findElement(muralgo);
	}
	public WebElement getlocation() {
		return driver.findElement(location);
	}
	public WebElement gettype_of_property() {
		return driver.findElement(type_of_property);
	}
	public WebElement getprojectdetails_continuebtn() {
		return driver.findElement(projectdetails_continuebtn);
	}

}
